rule(a(b(x)),x,y,z,b(a(x))).
