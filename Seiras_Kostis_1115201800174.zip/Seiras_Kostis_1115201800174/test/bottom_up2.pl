p(X, Y) :- q(s(X)), q(Y).
q(X) :- q(s(X)).
q(s(s(0))).
