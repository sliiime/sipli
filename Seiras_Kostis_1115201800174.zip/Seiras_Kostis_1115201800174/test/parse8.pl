rule(x,y,1) :- pred1(1,2,x), pred2(1,3,z), pred3(1,2,3).
