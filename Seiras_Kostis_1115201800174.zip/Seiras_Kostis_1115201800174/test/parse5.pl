rule(a,b).
