p(s(s(s(0)))).
p(X) :- p(s(X)).
