rule1(x,y,z) :- pred1(x,y,z), pred2(x,y,z).
