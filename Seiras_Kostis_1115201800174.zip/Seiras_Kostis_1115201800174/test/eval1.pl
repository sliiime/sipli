p(X,Y,Z) :- p1(X,Y,Z).
p1(s(X),s(X),s(X)).
