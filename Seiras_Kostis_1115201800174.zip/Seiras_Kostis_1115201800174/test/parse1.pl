rule(x) :- pred(y).
