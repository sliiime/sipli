legit(x).
